package com.emi.client.receipe.client.emi;

import com.emi.client.receipe.client.ClientRecipeFix;
import com.emi.client.receipe.client.VanillaRecipeLoader;
import dev.emi.emi.api.EmiEntrypoint;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.recipe.EmiCookingRecipe;
import dev.emi.emi.recipe.EmiShapedRecipe;
import dev.emi.emi.recipe.EmiShapelessRecipe;
import dev.emi.emi.recipe.EmiStonecuttingRecipe;
import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.ShapelessRecipe;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.crafting.SmokingRecipe;
import net.minecraft.world.item.crafting.StonecutterRecipe;

import java.util.List;

@EmiEntrypoint
public class ClientRecipeFixEmiPlugin implements EmiPlugin {

    public static boolean localRecipesRegistered = false;
    private static EmiRegistry recipeRegistry;

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public void register(EmiRegistry registry) {
        recipeRegistry = registry;

        // ★ 注意：我们不再注册自定义分类了，直接用原版分类
        ClientRecipeFix.LOGGER.info("EMI plugin initialized, using vanilla categories.");

        // 注册工作台 handler
        try {
            registry.addRecipeHandler((MenuType) MenuType.CRAFTING, new LocalRecipeHandler());
            ClientRecipeFix.LOGGER.info("LocalRecipeHandler registered for CRAFTING.");
        } catch (Throwable t) {
            ClientRecipeFix.LOGGER.error("Failed to register CRAFTING handler.", t);
        }

        // 注册背包 handler
        try {
            registry.addRecipeHandler((MenuType) null, new InventoryLocalRecipeHandler());
            ClientRecipeFix.LOGGER.info("InventoryLocalRecipeHandler registered for INVENTORY.");
        } catch (Throwable t) {
            ClientRecipeFix.LOGGER.error("Failed to register INVENTORY handler.", t);
        }

        // 注册炉子 handler
        try {
            registry.addRecipeHandler((MenuType) MenuType.FURNACE, new FurnaceLocalRecipeHandler());
            registry.addRecipeHandler((MenuType) MenuType.BLAST_FURNACE, new FurnaceLocalRecipeHandler());
            registry.addRecipeHandler((MenuType) MenuType.SMOKER, new FurnaceLocalRecipeHandler());
            ClientRecipeFix.LOGGER.info("FurnaceLocalRecipeHandler registered.");
        } catch (Throwable t) {
            ClientRecipeFix.LOGGER.error("Failed to register FURNACE handler.", t);
        }

        // 注册切石机 handler
        try {
            registry.addRecipeHandler((MenuType) MenuType.STONECUTTER, new StonecutterLocalRecipeHandler());
            ClientRecipeFix.LOGGER.info("StonecutterLocalRecipeHandler registered.");
        } catch (Throwable t) {
            ClientRecipeFix.LOGGER.error("Failed to register STONECUTTER handler.", t);
        }

        // 加载本地配方
        try {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null) {
                ClientRecipeFix.LOGGER.warn("Level not ready, skip.");
                return;
            }

            List<RecipeHolder<?>> recipes = VanillaRecipeLoader.loadVanillaRecipes(
                    client.level.registryAccess()
            );
            if (recipes.isEmpty()) {
                ClientRecipeFix.LOGGER.warn("No local recipes loaded.");
                return;
            }

            int count = 0;
            for (RecipeHolder<?> holder : recipes) {
                try {
                    var recipe = holder.value();

                    // 1. 工作台：有序合成（EmiShapedRecipe 自动使用 VanillaEmiRecipeCategories.CRAFTING）
                    if (recipe instanceof ShapedRecipe shaped) {
                        registry.addRecipe(new EmiShapedRecipe(shaped));
                    }
                    // 2. 工作台：无序合成
                    else if (recipe instanceof ShapelessRecipe shapeless) {
                        registry.addRecipe(new EmiShapelessRecipe(shapeless));
                    }
                    // 3. 熔炉（使用原版 SMELTING 分类）
                    else if (recipe instanceof SmeltingRecipe smelting) {
                        registry.addRecipe(new EmiCookingRecipe(smelting, VanillaEmiRecipeCategories.SMELTING, 200, false));
                    }
                    // 4. 高炉（使用原版 BLASTING 分类）
                    else if (recipe instanceof BlastingRecipe blasting) {
                        registry.addRecipe(new EmiCookingRecipe(blasting, VanillaEmiRecipeCategories.BLASTING, 100, false));
                    }
                    // 5. 烟熏炉（使用原版 SMOKING 分类）
                    else if (recipe instanceof SmokingRecipe smoking) {
                        registry.addRecipe(new EmiCookingRecipe(smoking, VanillaEmiRecipeCategories.SMOKING, 100, false));
                    }
                    // 6. 营火（使用原版 CAMPFIRE_COOKING 分类）
                    else if (recipe instanceof CampfireCookingRecipe campfire) {
                        registry.addRecipe(new EmiCookingRecipe(campfire, VanillaEmiRecipeCategories.CAMPFIRE_COOKING, 600, false));
                    }
                    // 7. 切石机（使用原版 STONECUTTING 分类）
                    else if (recipe instanceof StonecutterRecipe stonecutting) {
                        registry.addRecipe(new EmiStonecuttingRecipe(stonecutting));
                    }
                    // 8. 其他配方暂不处理
                    else {
                        // 暂不处理
                    }
                    count++;
                } catch (Exception e) {
                    ClientRecipeFix.LOGGER.warn("注入配方 {} 失败", holder.id(), e);
                }
            }
            localRecipesRegistered = true;
            ClientRecipeFix.LOGGER.info("Registered {} local recipes.", count);
        } catch (Exception e) {
            ClientRecipeFix.LOGGER.error("Failed to register local recipes.", e);
        }
    }

    public static void addRecipes(List<dev.emi.emi.api.recipe.EmiRecipe> recipes) {
        if (recipeRegistry == null) return;
        for (var recipe : recipes) {
            recipeRegistry.addRecipe(recipe);
        }
    }
}